# Robustness Summary

## Panel-level results

| Sample | RMSE imp. (%) | MAE imp. (%) | QLIKE imp. (%) | Robust pass | Pass windows |
|---|---:|---:|---:|---|---:|
| NVDA | -3.95 | -3.53 | 2.68 | No | 0 |
| pooled | -3.95 | -3.53 | 2.68 | No | 0 |

## Dispersion statistics

- Median RMSE improvement across pooled + per-ticker analyses: **-3.95%**.
- Cross-sample dispersion (std. dev.) of RMSE improvement: **0.00 pp**.
- Success criterion: at least **3** rolling windows with positive and significant (p < 0.05) gains plus consistent lag-coefficient sign.
